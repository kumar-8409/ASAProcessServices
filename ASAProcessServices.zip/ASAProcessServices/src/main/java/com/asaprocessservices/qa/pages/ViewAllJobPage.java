package com.asaprocessservices.qa.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.asaprocessservices.qa.base.TestBase;

public class ViewAllJobPage extends TestBase {

	@FindBy(xpath="//span[contains(text(),'View All')]")
	WebElement viewAll;
	
	@FindBy(xpath="//select[@id='ServiceTypeId']")
	WebElement serviceType;
	
	@FindBy(xpath="//select[@id='StatusId']")
	WebElement status;


	@FindBy(xpath="//input[@class='form-control form-control-sm']")
	WebElement search;
	
	
	public ViewAllJobPage() {
		PageFactory.initElements(driver, this);
	}



	public void clickOnViewAllLink() {
		viewAll.click();
	}

	public String verifyViewAllJobTitle() {
		return driver.getTitle();

	}
	
	public void verifyFilter() {
		Select service=new Select(serviceType);
		Select statust=new Select(status);
		
		List<WebElement> first = service.getOptions();
		List<WebElement> second = statust.getOptions();
		
		for(int i=0;i<first.size();i++) 
		{
			service.selectByIndex(i);
			for(int j=0;j<second.size();j++) 
			{
				statust.selectByIndex(j);
			}
		}
		
	}
	
	public void verifySearchServee() {
		search.sendKeys("INDI");
	}
	public void verifySearchCase() {
		search.sendKeys("CASE#3434");
	}
	public void verifySearchStatus() {
		search.sendKeys("pending");
	}

	public void verifySearchPriority() {
		search.sendKeys("Critical");
	}
	
	public void verifySearchServiceTpe() {
		search.sendKeys("High");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
