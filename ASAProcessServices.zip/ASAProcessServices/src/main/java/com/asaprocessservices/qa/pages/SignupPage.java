package com.asaprocessservices.qa.pages;

import com.asaprocessservices.qa.base.TestBase;

public class SignupPage extends TestBase {

}
