package com.asaprocessservices.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.asaprocessservices.qa.base.TestBase;

public class DashboardPage extends TestBase{

	//ViewAllPage viewAllPage;

	@FindBy(xpath="//span[@class='d-block']")
	WebElement lawFirm;

	@FindBy(xpath="//span[@class='text-bold']")
	WebElement viewAll;

	@FindBy(xpath="//a[text()='my jobs']")
	WebElement MyJobs;

	@FindBy(xpath="//a[@id='expjobs24']")
	WebElement HS24;

	@FindBy(xpath="//a[@id='expjobs48']")
	WebElement HS48; 

	@FindBy(xpath="//a[@id='expjobs72']")
	WebElement HS72;

	@FindBy(xpath="//span[text()='Jobs Expiring in 24 hours']")
	WebElement JobsExpiringin24hours;

	@FindBy(xpath="//a[@aria-controls='tblcourtdate'][normalize-space()='Next']")
	WebElement next;

	@FindBy(xpath="//a[@aria-controls='tblcourtdate'][normalize-space()='Last']")
	WebElement last;

	@FindBy(xpath="//a[@aria-controls='tblcourtdate'][normalize-space()='Previous']")
	WebElement previous;

	@FindBy(xpath="//a[@aria-controls='tblcourtdate'][normalize-space()='First']")
	WebElement first;

	@FindBy(linkText=("INDI"))
	WebElement servee;


	public DashboardPage() {
		PageFactory.initElements(driver, this);
	}


	public String verifyDashboardTitle() {
		return driver.getTitle();

	}

	public boolean verifyUserName() {
		return lawFirm.isDisplayed();
	}


	public ViewAllJobPage clickonViewall() { 
		viewAll.click(); 
		return new ViewAllJobPage();
	}

	public void clickOnMyJobs() {
		MyJobs.click();
	}

	public void clickon24HS() {
		HS24.click();
	}

	public void clickon48HS() {
		HS48.click();
	}
	public void clickon72HS() {
		HS72.click();
	}

	public void JobsExpiringin24hours() {
		JobsExpiringin24hours.click();
	}

	public void next() {next.click();}

	public void last() {
		last.click();
	}

	public void previous() {
		previous.click();
	}

	public void first() {
		first.click();
	}
	public void ServeeLink() {
		servee.click();


	}









}
