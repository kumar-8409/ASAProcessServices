package com.asaprocessservices.qa.pages;

public class MyJobsPage {

}
