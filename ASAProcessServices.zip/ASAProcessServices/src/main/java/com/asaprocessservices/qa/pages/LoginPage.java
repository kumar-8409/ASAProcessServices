package com.asaprocessservices.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.asaprocessservices.qa.base.TestBase;

public class LoginPage extends TestBase{
	


	@FindBy(xpath="//input[@id='Email']")
	WebElement email;
	
	@FindBy(name="Password")
	WebElement pass;
	
	@FindBy(id="btnlogin")
	WebElement login;
	
	@FindBy(xpath="//img[@class='img-left']")
	WebElement logo;
	
	public LoginPage() {
		
		PageFactory.initElements(driver, this);
	}
	
	
	public String loginPageTitle() {
		return driver.getTitle();
	}
	
	public boolean logoImage() {
		return logo.isDisplayed();		
	}
	
	public DashboardPage login(String username, String password) {
		email.sendKeys(username);
		pass.sendKeys(password);
		login.click();
		return new DashboardPage();
	}
	

	
	
	
}
