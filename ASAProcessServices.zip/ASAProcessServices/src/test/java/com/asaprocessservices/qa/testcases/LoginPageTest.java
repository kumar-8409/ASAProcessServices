package com.asaprocessservices.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.asaprocessservices.qa.base.TestBase;
import com.asaprocessservices.qa.pages.DashboardPage;
import com.asaprocessservices.qa.pages.LoginPage;

public class LoginPageTest extends TestBase{
	LoginPage loginPage;
	DashboardPage dashBoardPage;
	
	
	public LoginPageTest() {
		super();
	}
	
	@BeforeClass
	public void setUp() {
		initialization();
	    loginPage=new LoginPage();	
	  //  dashBoardPage=loginPage.login(prop.getProperty("username"),prop.getProperty("password"));
	}
	
	@Test(priority = 1)
	public void loginPageTitleTest() {
		String title=loginPage.loginPageTitle();
		System.out.print(title);
		Assert.assertEquals(title,"Dashboard" );
	}
	
	@Test(priority = 2)
	public void LogoTest() {
		boolean flag=loginPage.logoImage();
		Assert.assertTrue(flag);
	}
	
	@Test(priority = 3)
	public void LoginTest() {
		dashBoardPage= loginPage.login(prop.getProperty("username"),prop.getProperty("password"));
		
		
	}
	
	
	
	//@AfterClass public void tearDown() { driver.quit(); }
	 
	
	 

}
