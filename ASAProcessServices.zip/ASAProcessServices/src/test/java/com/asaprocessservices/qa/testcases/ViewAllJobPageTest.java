package com.asaprocessservices.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.asaprocessservices.qa.base.TestBase;
import com.asaprocessservices.qa.pages.DashboardPage;
import com.asaprocessservices.qa.pages.LoginPage;
import com.asaprocessservices.qa.pages.ViewAllJobPage;

public class ViewAllJobPageTest extends TestBase {

	LoginPage loginPage;
	DashboardPage dashboardPage;
	ViewAllJobPage viewAllJobPage;

	public ViewAllJobPageTest() {
		super();
	}

	@BeforeClass
	public void setUp() {
		initialization();
		loginPage = new LoginPage();
		viewAllJobPage = new ViewAllJobPage();
		dashboardPage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		//viewAllJobPage = dashboardPage.clickonViewall();

	}


	@Test(priority = 1) 
	public void verifyViewAllLink() {
		viewAllJobPage.clickOnViewAllLink();

	}


	@Test(priority = 2)
	public void verifyTitleOfViewAllJob() {
		String title = viewAllJobPage.verifyViewAllJobTitle();
		Assert.assertEquals(title, "https://innoserve.tech/LawFirm/ViewAllJobs", "ViewAllJobs title is not correct");
	}

	@Test(priority = 3)
	public void verifyfilterTest() {
		viewAllJobPage.verifyFilter();
		driver.navigate().refresh();

	}

	@Test(priority = 4)
	public void verifySearchServeeTest() {
		viewAllJobPage.verifySearchServee();
		driver.navigate().refresh();
	}

	@Test(priority = 5)
	public void verifySearchCaseTest() {
		viewAllJobPage.verifySearchCase();
		driver.navigate().refresh();
	}

	@Test(priority = 6)
	public void verifySearchStatusTest() {
		viewAllJobPage.verifySearchStatus();
		driver.navigate().refresh();
	}

	@Test(priority = 7)
	public void verifySearchPriorityTest() {
		viewAllJobPage.verifySearchPriority();
		driver.navigate().refresh();
	}

	@Test(priority = 8)
	public void verifySearchServiceTypeTest() {
		viewAllJobPage.verifySearchServiceTpe();
		driver.navigate().refresh();
	}

	/*
	 * @AfterClass public void tearDown() { driver.quit(); }
	 */

}
