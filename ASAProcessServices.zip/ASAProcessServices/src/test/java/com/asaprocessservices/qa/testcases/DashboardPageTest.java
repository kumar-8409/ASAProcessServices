package com.asaprocessservices.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.asaprocessservices.qa.pages.LoginPage;
import com.asaprocessservices.qa.base.TestBase;
import com.asaprocessservices.qa.pages.DashboardPage;

public class DashboardPageTest extends TestBase {
	LoginPage loginPage;
	DashboardPage dashboardPage;
	public DashboardPageTest() {
		super();
	}

	@BeforeClass
	public void setUp() {
		initialization();
		loginPage=new LoginPage();	
		dashboardPage=loginPage.login(prop.getProperty("username"),prop.getProperty("password"));
	}


	@Test(priority = 1)
	public void verifyDashboard() {
		String title=dashboardPage.verifyDashboardTitle();
		Assert.assertEquals(title, "Dashboard","Dashboard title is not correct");
	}

	@Test(priority = 2)
	public void verifyUserNameTest() {
		Assert.assertTrue(dashboardPage.verifyUserName());

	}


	@Test(priority = 3) public void verifyViewAllPage() {
		dashboardPage.clickonViewall(); driver.navigate().back();

	}



	@Test(priority = 4) public void VerifyMyJobs(){
		dashboardPage.clickOnMyJobs(); driver.navigate().back(); }


	@Test(priority = 5)
	public void verify24HS() {
		dashboardPage.clickon24HS();
	}

	@Test(priority = 6)
	public void verify48HS() {
		dashboardPage.clickon48HS();
	}

	@Test(priority = 7)
	public void verify72HS() {
		dashboardPage.clickon72HS();
	}

	@Test(priority = 8)
	public void verifyJobsExpiringin24hoursLink(){
		dashboardPage.JobsExpiringin24hours();
		driver.navigate().back();
	}

	@Test(priority = 9)
	public void verifyNext() {
		dashboardPage.next();
	}

	@Test(priority = 10)
	public void verifyLast() {
		dashboardPage.last();
	}

	@Test(priority = 11)
	public void verifyPrevious() {
		dashboardPage.previous();
	}

	@Test(priority = 12)
	public void verifyFirst() {
		dashboardPage.first();
	}

	@Test(priority = 13)
	public void verifyServeeLink() {
		dashboardPage.ServeeLink();
		driver.navigate().back();
	}









	
	 //@AfterClass public void tearDown() { driver.quit(); }
	 



}
